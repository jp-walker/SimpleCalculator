package hu.ait.simplecalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import hu.ait.simplecalculator.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPlus.setOnClickListener {
            val firstNumber = binding.firstPosition.text.toString().toIntOrNull()
            val secondNumber = binding.secondPosition.text.toString().toIntOrNull()
            Log.d("TAG_DEMO", "Plus pressed $firstNumber, $secondNumber")
            if (firstNumber != null && secondNumber != null) {
                val resultValue = firstNumber + secondNumber
                binding.result.text = "Result: $resultValue"
            }
            else {
                binding.result.setText(R.string.result);

            }
        }

        binding.btnMinus.setOnClickListener {
            val firstNumber = binding.firstPosition.text.toString().toIntOrNull()
            val secondNumber = binding.secondPosition.text.toString().toIntOrNull()
            Log.d("TAG_DEMO", "Minus pressed $firstNumber, $secondNumber")
            if (firstNumber != null && secondNumber != null) {
                val resultValue = firstNumber - secondNumber
                binding.result.text = "Result: $resultValue"
            }
            else {
                binding.result.setText(R.string.result);
            }
        }


    }
    }